import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import seaborn as sns

def create_evaluation_folder():
    """Create a folder on desktop for evaluation results"""
    desktop_path = os.path.expanduser("~/Desktop")
    eval_folder = os.path.join(desktop_path, "Motor_Evaluation_Results")
    if not os.path.exists(eval_folder):
        os.makedirs(eval_folder)
    return eval_folder

def load_and_process_data(folder_path):
    """
    Load all CSV files from the specified folder and process them for system identification
    """
    all_drive_data = []
    all_steer_data = []
    
    for file in os.listdir(folder_path):
        if file.endswith('.csv'):
            df = pd.read_csv(os.path.join(folder_path, file))
            
            # Skip the header row and use numerical indexing
            if df.iloc[0, 0] == 'timestamp':  # If first row is header
                df = df.iloc[1:]  # Skip header row
                df = df.astype(float)  # Convert all to numeric
            
            # Reset index and add timestamp if not present
            df = df.reset_index(drop=True)
            if 0 not in df.columns:  # If no timestamp column
                df['timestamp'] = np.arange(len(df)) * 0.02
            else:
                # Rename the first column to timestamp
                df = df.rename(columns={df.columns[0]: 'timestamp'})
            
            print(f"Processing {file}, shape: {df.shape}")
            
            # Process drive motors (4 motors)
            for i in range(4):
                # Input: voltage, Output: velocity
                motor_data = pd.DataFrame()
                motor_data['timestamp'] = df.iloc[:, 0]  # timestamp from first column
                motor_data['voltage'] = df.iloc[:, 1 + i]  # drive voltages columns 1-4
                motor_data['velocity'] = df.iloc[:, 5 + i]  # drive velocities columns 5-8
                motor_data['motor_id'] = i
                motor_data['dataset'] = file
                all_drive_data.append(motor_data)
            
            # Process steering motors (4 motors)
            for i in range(4):
                # Input: voltage, Output: velocity
                motor_data = pd.DataFrame()
                motor_data['timestamp'] = df.iloc[:, 0]  # timestamp from first column
                motor_data['voltage'] = df.iloc[:, 13 + i]  # steering voltages columns 13-16
                motor_data['velocity'] = df.iloc[:, 17 + i]  # steering velocities columns 17-20
                motor_data['motor_id'] = i + 4  # IDs 4-7 for steering motors
                motor_data['dataset'] = file
                all_steer_data.append(motor_data)
    
    drive_combined = pd.concat(all_drive_data, ignore_index=True) if all_drive_data else pd.DataFrame()
    steer_combined = pd.concat(all_steer_data, ignore_index=True) if all_steer_data else pd.DataFrame()
    
    return drive_combined, steer_combined

def create_features_targets(df, motor_id):
    """
    Create features (X) and targets (y) for a specific motor
    Features: [sign(velocity), voltage, current_velocity, acceleration]
    Target: next_velocity
    """
    if df.empty:
        return np.array([]), np.array([]), pd.DataFrame()
    
    motor_data = df[df['motor_id'] == motor_id].copy()
    if motor_data.empty:
        return np.array([]), np.array([]), pd.DataFrame()
    
    motor_data = motor_data.sort_values(['dataset', 'timestamp']).reset_index(drop=True)
    
    # Calculate acceleration (derivative of velocity)
    motor_data['acceleration'] = motor_data.groupby('dataset')['velocity'].diff() / motor_data.groupby('dataset')['timestamp'].diff()
    
    # Add sign of velocity
    motor_data['sign_vel'] = np.sign(motor_data['velocity'])
    
    # Create target (velocity at next timestep)
    motor_data['next_velocity'] = motor_data.groupby('dataset')['velocity'].shift(-1)
    
    # Remove NaN values
    motor_data = motor_data.dropna()
    
    if len(motor_data) == 0:
        return np.array([]), np.array([]), pd.DataFrame()
    
    # Create feature matrix X and target vector y
    X = motor_data[['sign_vel', 'voltage', 'velocity', 'acceleration']].values
    y = motor_data['next_velocity'].values
    
    return X, y, motor_data

def create_evaluation_plots(y_true, y_pred, motor_id, eval_folder):
    """
    Create comprehensive evaluation plots for a motor
    """
    # Calculate metrics
    mse = mean_squared_error(y_true, y_pred)
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    errors = y_pred - y_true
    
    # Create figure with 4 subplots
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    fig.suptitle(f'Evaluation for Motor {motor_id}', fontsize=16)
    
    # 1. Scatter plot of true vs predicted values
    axes[0, 0].scatter(y_true, y_pred, alpha=0.5)
    min_val = min(y_true.min(), y_pred.min())
    max_val = max(y_true.max(), y_pred.max())
    axes[0, 0].plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=2)
    axes[0, 0].set_xlabel('True Values')
    axes[0, 0].set_ylabel('Predictions')
    axes[0, 0].set_title(f'True vs Predicted\nMSE: {mse:.6f}, R²: {r2:.6f}, MAE: {mae:.6f}')
    axes[0, 0].grid(True, alpha=0.3)
    
    # 2. Error distribution histogram
    axes[0, 1].hist(errors, bins=50, alpha=0.7, edgecolor='black')
    axes[0, 1].axvline(x=0, color='r', linestyle='--')
    axes[0, 1].set_xlabel('Prediction Error')
    axes[0, 1].set_ylabel('Frequency')
    axes[0, 1].set_title('Error Distribution')
    axes[0, 1].grid(True, alpha=0.3)
    
    # 3. Time series comparison (first 100 samples)
    sample_size = min(100, len(y_true))
    axes[1, 0].plot(range(sample_size), y_true[:sample_size], label='True', linewidth=2)
    axes[1, 0].plot(range(sample_size), y_pred[:sample_size], label='Predicted', linewidth=2, alpha=0.8)
    axes[1, 0].set_xlabel('Time Step')
    axes[1, 0].set_ylabel('Velocity (rad/s)')
    axes[1, 0].set_title('Time Series Comparison (First 100 Samples)')
    axes[1, 0].legend()
    axes[1, 0].grid(True, alpha=0.3)
    
    # 4. Residual plot
    axes[1, 1].scatter(y_pred, errors, alpha=0.5)
    axes[1, 1].axhline(y=0, color='r', linestyle='--')
    axes[1, 1].set_xlabel('Predicted Values')
    axes[1, 1].set_ylabel('Residuals')
    axes[1, 1].set_title('Residual Plot')
    axes[1, 1].grid(True, alpha=0.3)
    
    # Save the figure
    plt.tight_layout()
    plt.savefig(os.path.join(eval_folder, f'motor_{motor_id}_evaluation.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    return mse, mae, r2

def extract_motor_parameters(model, scaler, motor_id):
    """
    Extract and properly scale motor parameters from the trained model
    """
    if model is None:
        return None, None, None, None
    
    # Get raw coefficients [sign_vel, voltage, velocity, acceleration]
    coef = model.coef_
    intercept = model.intercept_
    
    # For standardized features, we need to reverse the scaling
    # to get parameters in original units
    if scaler is not None and hasattr(scaler, 'scale_') and hasattr(scaler, 'mean_'):
        # Scale factors for voltage, velocity, acceleration
        voltage_scale = scaler.scale_[0]  # voltage is at index 0 in scaled
        velocity_scale = scaler.scale_[1]  # velocity at index 1
        acceleration_scale = scaler.scale_[2]  # acceleration at index 2
        
        # Reverse the standardization for proper parameter extraction
        # The standard motor model is: V = ks*sign(ω) + kv*ω + ka*α
        # Note: This extraction assumes the model approximates the dynamics, but the features include voltage as input.
        # For consistency with the comment, we extract ks, kv, ka, but note the model is for next_velocity.
        ks = coef[0]  # sign_vel coefficient (not scaled)
        k_voltage = coef[1] / voltage_scale  # voltage coefficient
        kv = coef[2] / velocity_scale  # velocity coefficient
        ka = coef[3] / acceleration_scale  # acceleration coefficient
        
        # Adjust intercept for standardization
        means = scaler.mean_
        scales = scaler.scale_
        intercept_adjust = np.sum(coef[1:] * means / scales)
        intercept = intercept - intercept_adjust
        
        # Returning ks, k_voltage, kv, ka for completeness, but original only used ks, kv, ka
        return ks, k_voltage, kv, ka, intercept
    else:
        ks = coef[0]
        k_voltage = coef[1]
        kv = coef[2]
        ka = coef[3]
    
    return ks, k_voltage, kv, ka, intercept

def train_motor_models(drive_data, steer_data, eval_folder):
    """
    Train models for all 8 motors and return results
    """
    all_mse = []
    all_mae = []
    all_r2 = []
    models = {}
    scalers = {}
    
    # Collect all validation data for overall metrics
    all_y_true = []
    all_y_pred = []
    
    for motor_id in range(8):
        print(f"Processing motor {motor_id}...")
        
        if motor_id < 4:
            X, y, motor_data = create_features_targets(drive_data, motor_id)
        else:
            X, y, motor_data = create_features_targets(steer_data, motor_id)
        
        if len(X) == 0 or len(y) == 0:
            print(f"Warning: No data for motor {motor_id}")
            all_mse.append(np.nan)
            all_mae.append(np.nan)
            all_r2.append(np.nan)
            models[motor_id] = None
            scalers[motor_id] = None
            continue
        
        # Standardize features (excluding sign_vel which is already -1, 0, 1)
        scaler = StandardScaler()
        # Only scale voltage, velocity, acceleration (columns 1, 2, 3)
        X_to_scale = X[:, 1:]  # Exclude sign_vel
        X_scaled = X.copy()
        if len(X_to_scale) > 0:
            X_scaled[:, 1:] = scaler.fit_transform(X_to_scale)
        scalers[motor_id] = scaler
        
        # Split data into training and validation sets
        X_train, X_val, y_train, y_val = train_test_split(X_scaled, y, test_size=0.2, random_state=42)
        
        # Train linear regression model
        model = LinearRegression()
        model.fit(X_train, y_train)
        
        # Make predictions
        y_pred = model.predict(X_val)
        
        # Create evaluation plots and get metrics
        mse, mae, r2 = create_evaluation_plots(y_val, y_pred, motor_id, eval_folder)
        
        all_mse.append(mse)
        all_mae.append(mae)
        all_r2.append(r2)
        models[motor_id] = model
        
        # Collect data for overall metrics
        all_y_true.extend(y_val)
        all_y_pred.extend(y_pred)
        
        print(f"Motor {motor_id} MSE: {mse:.6f}, MAE: {mae:.6f}, R²: {r2:.6f}, Samples: {len(X)}")
    
    # Calculate overall metrics
    if all_y_true:
        overall_mse = mean_squared_error(all_y_true, all_y_pred)
        overall_mae = mean_absolute_error(all_y_true, all_y_pred)
        overall_r2 = r2_score(all_y_true, all_y_pred)
    else:
        overall_mse = np.nan
        overall_mae = np.nan
        overall_r2 = np.nan
    
    return all_mse, all_mae, all_r2, models, scalers, overall_mse, overall_mae, overall_r2

def create_summary_plots(mse_results, mae_results, r2_results, eval_folder):
    """Create summary plots for all motors"""
    # MSE summary plot
    plt.figure(figsize=(10, 6))
    plt.bar(range(8), mse_results)
    plt.title('MSE for Each Motor')
    plt.xlabel('Motor ID')
    plt.ylabel('Mean Squared Error')
    plt.xticks(range(8))
    plt.grid(True, alpha=0.3)
    plt.savefig(os.path.join(eval_folder, 'mse_summary.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # MAE summary plot
    plt.figure(figsize=(10, 6))
    plt.bar(range(8), mae_results)
    plt.title('MAE for Each Motor')
    plt.xlabel('Motor ID')
    plt.ylabel('Mean Absolute Error')
    plt.xticks(range(8))
    plt.grid(True, alpha=0.3)
    plt.savefig(os.path.join(eval_folder, 'mae_summary.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # R² summary plot
    plt.figure(figsize=(10, 6))
    plt.bar(range(8), r2_results)
    plt.title('R² Score for Each Motor')
    plt.xlabel('Motor ID')
    plt.ylabel('R² Score')
    plt.xticks(range(8))
    plt.grid(True, alpha=0.3)
    plt.savefig(os.path.join(eval_folder, 'r2_summary.png'), dpi=300, bbox_inches='tight')
    plt.close()

def save_metrics_to_file(mse_results, mae_results, r2_results, overall_mse, overall_mae, overall_r2, eval_folder, models, scalers):
    """Save all metrics to a text file"""
    metrics_file = os.path.join(eval_folder, "metrics_summary.txt")
    
    with open(metrics_file, 'w') as f:
        f.write("MOTOR PERFORMANCE METRICS SUMMARY\n")
        f.write("=" * 50 + "\n\n")
        
        f.write("INDIVIDUAL MOTOR METRICS:\n")
        f.write("-" * 30 + "\n")
        f.write("Motor ID\tMSE\t\tMAE\t\tR²\n")
        f.write("-" * 50 + "\n")
        
        for motor_id, (mse, mae, r2) in enumerate(zip(mse_results, mae_results, r2_results)):
            if not np.isnan(mse):
                f.write(f"{motor_id}\t\t{mse:.6f}\t{mae:.6f}\t{r2:.6f}\n")
            else:
                f.write(f"{motor_id}\t\tNo data available\n")
        
        f.write("\nOVERALL VALIDATION METRICS:\n")
        f.write("-" * 30 + "\n")
        f.write(f"MSE: {overall_mse:.6f}\n")
        f.write(f"MAE: {overall_mae:.6f}\n")
        f.write(f"R²: {overall_r2:.6f}\n")
        
        f.write("\nMODEL PARAMETERS (ks, k_voltage, kv, ka):\n")
        f.write("-" * 30 + "\n")
        for motor_id in range(8):
            if not np.isnan(mse_results[motor_id]):
                # Extract properly scaled parameters
                ks, k_voltage, kv, ka, intercept = extract_motor_parameters(
                    models[motor_id], scalers[motor_id], motor_id
                )
                
                f.write(f"Motor {motor_id}: ks={ks:.4f}, k_voltage={k_voltage:.4f}, kv={kv:.4f}, ka={ka:.4f}, intercept={intercept:.4f}\n")
            else:
                f.write(f"Motor {motor_id}: No model available\n")
    
    return metrics_file

def save_metrics_to_csv(mse_results, mae_results, r2_results, overall_mse, overall_mae, overall_r2, eval_folder, models, scalers):
    """Save all metrics and parameters to CSV files"""
    # Individual motors metrics and parameters
    data = {
        'Motor ID': range(8),
        'MSE': mse_results,
        'MAE': mae_results,
        'R2': r2_results
    }
    
    ks_list = []
    k_voltage_list = []
    kv_list = []
    ka_list = []
    intercept_list = []
    
    for motor_id in range(8):
        if not np.isnan(mse_results[motor_id]):
            ks, k_voltage, kv, ka, intercept = extract_motor_parameters(
                models[motor_id], scalers[motor_id], motor_id
            )
            ks_list.append(ks)
            k_voltage_list.append(k_voltage)
            kv_list.append(kv)
            ka_list.append(ka)
            intercept_list.append(intercept)
        else:
            ks_list.append(np.nan)
            k_voltage_list.append(np.nan)
            kv_list.append(np.nan)
            ka_list.append(np.nan)
            intercept_list.append(np.nan)
    
    data['ks'] = ks_list
    data['k_voltage'] = k_voltage_list
    data['kv'] = kv_list
    data['ka'] = ka_list
    data['intercept'] = intercept_list
    
    df = pd.DataFrame(data)
    metrics_csv = os.path.join(eval_folder, 'metrics_summary.csv')
    df.to_csv(metrics_csv, index=False)
    
    # Overall metrics
    overall_data = {
        'Metric': ['MSE', 'MAE', 'R2'],
        'Value': [overall_mse, overall_mae, overall_r2]
    }
    overall_df = pd.DataFrame(overall_data)
    overall_csv = os.path.join(eval_folder, 'overall_metrics.csv')
    overall_df.to_csv(overall_csv, index=False)
    
    return metrics_csv, overall_csv

def main():
    # Path to data folder
    folder_path = os.path.expanduser("~/Desktop/CLEANED3")
    
    # Create evaluation folder
    eval_folder = create_evaluation_folder()
    print(f"Evaluation results will be saved to: {eval_folder}")
    
    # Check if folder exists
    if not os.path.exists(folder_path):
        print(f"Error: Folder {folder_path} does not exist!")
        return
    
    # Load and process data
    print("Loading and processing data...")
    drive_data, steer_data = load_and_process_data(folder_path)
    
    print(f"Drive data shape: {drive_data.shape if not drive_data.empty else 'Empty'}")
    print(f"Steer data shape: {steer_data.shape if not steer_data.empty else 'Empty'}")
    
    # Train models for all motors
    print("Training models...")
    mse_results, mae_results, r2_results, models, scalers, overall_mse, overall_mae, overall_r2 = train_motor_models(drive_data, steer_data, eval_folder)
    
    # Create summary plots
    create_summary_plots(mse_results, mae_results, r2_results, eval_folder)
    
    # Save metrics to file
    metrics_file = save_metrics_to_file(mse_results, mae_results, r2_results, overall_mse, overall_mae, overall_r2, eval_folder, models, scalers)
    
    # Save metrics to CSV
    metrics_csv, overall_csv = save_metrics_to_csv(mse_results, mae_results, r2_results, overall_mse, overall_mae, overall_r2, eval_folder, models, scalers)
    
    # Print final results to terminal
    print("\nFinal Results:")
    print("INDIVIDUAL MOTOR METRICS:")
    print("Motor ID\tMSE\t\tMAE\t\tR²")
    print("-" * 50)
    for motor_id, (mse, mae, r2) in enumerate(zip(mse_results, mae_results, r2_results)):
        if not np.isnan(mse):
            print(f"{motor_id}\t\t{mse:.6f}\t{mae:.6f}\t{r2:.6f}")
        else:
            print(f"{motor_id}\t\tNo data available")
    
    print("\nOVERALL VALIDATION METRICS:")
    print(f"MSE: {overall_mse:.6f}")
    print(f"MAE: {overall_mae:.6f}")
    print(f"R²: {overall_r2:.6f}")
    
    print("\nModel Parameters (ks, k_voltage, kv, ka):")
    for motor_id in range(8):
        if not np.isnan(mse_results[motor_id]):
            # Extract properly scaled parameters
            ks, k_voltage, kv, ka, intercept = extract_motor_parameters(
                models[motor_id], scalers[motor_id], motor_id
            )
            
            print(f"Motor {motor_id}: ks={ks:.4f}, k_voltage={k_voltage:.4f}, kv={kv:.4f}, ka={ka:.4f}, intercept={intercept:.4f}")
        else:
            print(f"Motor {motor_id}: No model available")
    
    print(f"\nEvaluation plots saved to: {eval_folder}")
    print(f"Metrics summary saved to: {metrics_file}")
    print(f"Metrics CSV saved to: {metrics_csv}")
    print(f"Overall metrics CSV saved to: {overall_csv}")

if __name__ == "__main__":
    main()