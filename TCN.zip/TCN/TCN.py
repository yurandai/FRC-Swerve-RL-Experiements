# train_tcn.py
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Conv1D, Dropout, Activation
from tensorflow.keras.layers import Add, BatchNormalization, GlobalAveragePooling1D
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.regularizers import l2
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import pickle
import warnings
from scipy import stats
warnings.filterwarnings('ignore')

# Configuration
SEQUENCE_LENGTHS = [20]  # Multiple sequence lengths to test
BATCH_SIZE = 32
EPOCHS = 150
VALIDATION_SPLIT = 0.2
RANDOM_STATE = 42

# Target indices (0-based) - updated after removing timestamp column
TARGET_INDICES = [16, 17, 18, 19]
TARGET_NAMES = [
    'TurnVelocityRadPerSec_Module0',
    'TurnVelocityRadPerSec_Module1',
    'TurnVelocityRadPerSec_Module2',
    'TurnVelocityRadPerSec_Module3'
]

# Enhanced TCN Block with more regularization
def tcn_block(input_layer, dilation_rate, filters, kernel_size, dropout_rate=0.2, l2_reg=1e-4):
    # First convolution
    x = Conv1D(filters, kernel_size, padding='same', dilation_rate=dilation_rate,
               kernel_initializer='he_normal', kernel_regularizer=l2(l2_reg))(input_layer)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = Dropout(dropout_rate)(x)
    
    # Second convolution
    x = Conv1D(filters, kernel_size, padding='same', dilation_rate=dilation_rate,
               kernel_initializer='he_normal', kernel_regularizer=l2(l2_reg))(x)
    x = BatchNormalization()(x)
    x = Dropout(dropout_rate)(x)
    
    # Skip connection if needed
    if input_layer.shape[-1] != filters:
        input_layer = Conv1D(filters, 1, padding='same', 
                            kernel_regularizer=l2(l2_reg))(input_layer)
    
    # Add skip connection
    x = Add()([x, input_layer])
    x = Activation('relu')(x)
    
    return x

def build_tcn_model(input_shape, output_dim):
    """Build a regularized Temporal Convolutional Network model"""
    inputs = Input(shape=input_shape)
    
    # Input normalization
    x = BatchNormalization()(inputs)
    
    # Initial convolution to expand channels
    x = Conv1D(128, 1, padding='same', kernel_initializer='he_normal', 
               kernel_regularizer=l2(1e-4))(x)
    
    # TCN blocks with increasing dilation rates
    dilation_rates = [1, 2, 4, 8, 16, 32]
    for rate in dilation_rates:
        x = tcn_block(x, rate, 128, 3, dropout_rate=0.2, l2_reg=1e-4)
    
    # Global average pooling and output layer
    x = GlobalAveragePooling1D()(x)
    x = Dense(64, activation='relu', kernel_initializer='he_normal', 
              kernel_regularizer=l2(1e-4))(x)
    x = Dropout(0.3)(x)
    x = Dense(32, activation='relu', kernel_initializer='he_normal', 
              kernel_regularizer=l2(1e-4))(x)
    x = Dropout(0.3)(x)
    
    # Output layer - no activation for regression
    outputs = Dense(output_dim)(x)
    
    model = Model(inputs, outputs)
    model.compile(optimizer=Adam(learning_rate=0.0003),  # Lower learning rate
                  loss='mse', 
                  metrics=['mae'])
    
    return model

def load_and_preprocess_data(folder_path, sequence_length):
    """Load all CSV files from the folder and preprocess them with scaling"""
    all_files = [f for f in os.listdir(folder_path) if f.endswith('.csv')]
    print(f"Found {len(all_files)} CSV files")
    
    all_sequences = []
    all_targets = []
    file_names = []
    
    # First pass to fit scalers
    print("Fitting scalers...")
    all_data_for_scaling = []
    for file in all_files:
        file_path = os.path.join(folder_path, file)
        try:
            # Skip the first column (timestamp)
            df = pd.read_csv(file_path, skiprows=1).iloc[:, 1:]
            if len(df) > sequence_length:
                all_data_for_scaling.append(df.values.astype(np.float32))
        except Exception as e:
            print(f"Error processing {file} in first pass: {str(e)}")
            continue
    
    # Concatenate all data for scaling
    if not all_data_for_scaling:
        raise ValueError("No valid data found for scaling")
    
    all_data_for_scaling = np.vstack(all_data_for_scaling)
    feature_scaler = StandardScaler()
    target_scaler = StandardScaler()
    
    # Fit scalers
    feature_scaler.fit(all_data_for_scaling)
    target_scaler.fit(all_data_for_scaling[:, TARGET_INDICES])
    
    # Second pass to create scaled sequences
    print("Creating scaled sequences...")
    for file in all_files:
        file_path = os.path.join(folder_path, file)
        try:
            # Skip the first column (timestamp)
            df = pd.read_csv(file_path, skiprows=1).iloc[:, 1:]
            
            if len(df) < sequence_length + 1:
                continue
                
            # Scale the data - FIXED: astype instead of ast
            data = df.values.astype(np.float32)
            scaled_data = feature_scaler.transform(data)
            scaled_targets = target_scaler.transform(data[:, TARGET_INDICES])
            
            # Create sequences
            for i in range(len(df) - sequence_length):
                sequence = scaled_data[i:i+sequence_length]
                target = scaled_targets[i+sequence_length]
                
                all_sequences.append(sequence)
                all_targets.append(target)
                file_names.append(file)
                
        except Exception as e:
            print(f"Error processing {file} in second pass: {str(e)}")
            continue
    
    if len(all_sequences) == 0:
        raise ValueError(f"No sequences created for sequence length {sequence_length}")
    
    return (np.array(all_sequences), np.array(all_targets), file_names, 
            feature_scaler, target_scaler)

def create_train_val_split(sequences, targets, file_names):
    """Split data into training and validation sets by file"""
    unique_files = list(set(file_names))
    train_files, val_files = train_test_split(
        unique_files, test_size=VALIDATION_SPLIT, random_state=RANDOM_STATE
    )
    
    train_indices = [i for i, f in enumerate(file_names) if f in train_files]
    val_indices = [i for i, f in enumerate(file_names) if f in val_files]
    
    X_train = sequences[train_indices]
    y_train = targets[train_indices]
    X_val = sequences[val_indices]
    y_val = targets[val_indices]
    
    return X_train, X_val, y_train, y_val

def plot_training_history(history, save_path):
    """Plot training history and save to file"""
    plt.figure(figsize=(12, 5))
    
    plt.subplot(1, 2, 1)
    plt.plot(history.history['loss'], label='Training Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.title('Model Loss (MSE)')
    plt.ylabel('Loss')
    plt.xlabel('Epoch')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    plt.subplot(1, 2, 2)
    plt.plot(history.history['mae'], label='Training MAE')
    plt.plot(history.history['val_mae'], label='Validation MAE')
    plt.title('Model MAE')
    plt.ylabel('MAE')
    plt.xlabel('Epoch')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(os.path.join(save_path, 'training_history.png'), dpi=300, bbox_inches='tight')
    plt.close()

def apply_bias_correction(y_pred, y_true):
    """Apply linear bias correction to predictions based on error patterns"""
    corrected_preds = np.copy(y_pred)
    for i in range(y_pred.shape[1]):
        # Calculate the error pattern
        errors = y_pred[:, i] - y_true[:, i]
        
        # Fit a linear model to predict error from prediction
        slope, intercept, r_value, p_value, std_err = stats.linregress(y_pred[:, i], errors)
        
        # Apply correction: subtract the predicted error
        corrected_preds[:, i] = y_pred[:, i] - (slope * y_pred[:, i] + intercept)
        
        print(f"Target {TARGET_NAMES[i]}: Error = {slope:.4f} * prediction + {intercept:.4f} (R²={r_value**2:.4f})")
    
    return corrected_preds

def evaluate_model(model, X_val, y_val, target_scaler, save_path, sequence_length):
    """Evaluate model and create detailed visualizations for each target with bias correction"""
    # Make predictions
    y_pred = model.predict(X_val)
    
    # Inverse transform predictions and targets
    y_pred_rescaled = target_scaler.inverse_transform(y_pred)
    y_val_rescaled = target_scaler.inverse_transform(y_val)
    
    # Apply bias correction
    y_pred_corrected = apply_bias_correction(y_pred_rescaled, y_val_rescaled)
    
    # Calculate overall metrics for both original and corrected predictions
    mse = mean_squared_error(y_val_rescaled, y_pred_rescaled)
    mae = mean_absolute_error(y_val_rescaled, y_pred_rescaled)
    r2 = r2_score(y_val_rescaled, y_pred_rescaled)
    
    mse_corrected = mean_squared_error(y_val_rescaled, y_pred_corrected)
    mae_corrected = mean_absolute_error(y_val_rescaled, y_pred_corrected)
    r2_corrected = r2_score(y_val_rescaled, y_pred_corrected)
    
    print(f"\nOverall Validation Metrics (Original):")
    print(f"MSE: {mse:.6f}, MAE: {mae:.6f}, R²: {r2:.6f}")
    print(f"Overall Validation Metrics (Corrected):")
    print(f"MSE: {mse_corrected:.6f}, MAE: {mae_corrected:.6f}, R²: {r2_corrected:.6f}")
    print(f"Improvement: MSE {((mse - mse_corrected)/mse*100):.2f}%, MAE {((mae - mae_corrected)/mae*100):.2f}%")
    
    # Create evaluation for each target
    for i, target_name in enumerate(TARGET_NAMES):
        print(f"\n--- Evaluation for {target_name} ---")
        
        # Original predictions
        target_mse = mean_squared_error(y_val_rescaled[:, i], y_pred_rescaled[:, i])
        target_mae = mean_absolute_error(y_val_rescaled[:, i], y_pred_rescaled[:, i])
        target_r2 = r2_score(y_val_rescaled[:, i], y_pred_rescaled[:, i])
        
        # Corrected predictions
        target_mse_corrected = mean_squared_error(y_val_rescaled[:, i], y_pred_corrected[:, i])
        target_mae_corrected = mean_absolute_error(y_val_rescaled[:, i], y_pred_corrected[:, i])
        target_r2_corrected = r2_score(y_val_rescaled[:, i], y_pred_corrected[:, i])
        
        print(f"Original - MSE: {target_mse:.6f}, MAE: {target_mae:.6f}, R²: {target_r2:.6f}")
        print(f"Corrected - MSE: {target_mse_corrected:.6f}, MAE: {target_mae_corrected:.6f}, R²: {target_r2_corrected:.6f}")
        print(f"Improvement: MSE {((target_mse - target_mse_corrected)/target_mse*100):.2f}%")
        
        # Create comprehensive visualization for this target
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        fig.suptitle(f'Model Evaluation for {target_name} (SeqLen={sequence_length})', fontsize=16)
        
        # 1. Scatter plot of true vs predicted values (original)
        axes[0, 0].scatter(y_val_rescaled[:, i], y_pred_rescaled[:, i], alpha=0.5, label='Original')
        min_val = min(y_val_rescaled[:, i].min(), y_pred_rescaled[:, i].min())
        max_val = max(y_val_rescaled[:, i].max(), y_pred_rescaled[:, i].max())
        axes[0, 0].plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=2)
        axes[0, 0].set_xlabel('True Values')
        axes[0, 0].set_ylabel('Predictions')
        axes[0, 0].set_title(f'Original: MSE={target_mse:.6f}')
        axes[0, 0].grid(True, alpha=0.3)
        
        # 2. Scatter plot of true vs predicted values (corrected)
        axes[0, 1].scatter(y_val_rescaled[:, i], y_pred_corrected[:, i], alpha=0.5, label='Corrected', color='green')
        axes[0, 1].plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=2)
        axes[0, 1].set_xlabel('True Values')
        axes[0, 1].set_ylabel('Predictions')
        axes[0, 1].set_title(f'Corrected: MSE={target_mse_corrected:.6f}')
        axes[0, 1].grid(True, alpha=0.3)
        
        # 3. Error distribution comparison
        errors_original = y_pred_rescaled[:, i] - y_val_rescaled[:, i]
        errors_corrected = y_pred_corrected[:, i] - y_val_rescaled[:, i]
        
        axes[0, 2].hist(errors_original, bins=50, alpha=0.7, label='Original', edgecolor='black')
        axes[0, 2].hist(errors_corrected, bins=50, alpha=0.7, label='Corrected', edgecolor='black')
        axes[0, 2].axvline(x=0, color='r', linestyle='--')
        axes[0, 2].set_xlabel('Prediction Error')
        axes[0, 2].set_ylabel('Frequency')
        axes[0, 2].set_title('Error Distribution Comparison')
        axes[0, 2].legend()
        axes[0, 2].grid(True, alpha=0.3)
        
        # 4. Time series comparison (first 100 samples)
        n_samples = min(100, len(y_val_rescaled))
        axes[1, 0].plot(range(n_samples), y_val_rescaled[:n_samples, i], label='True', linewidth=2)
        axes[1, 0].plot(range(n_samples), y_pred_rescaled[:n_samples, i], label='Original Pred', linewidth=2, alpha=0.8)
        axes[1, 0].plot(range(n_samples), y_pred_corrected[:n_samples, i], label='Corrected Pred', linewidth=2, alpha=0.8)
        axes[1, 0].set_xlabel('Time Step')
        axes[1, 0].set_ylabel('Value')
        axes[1, 0].set_title('Time Series Comparison')
        axes[1, 0].legend()
        axes[1, 0].grid(True, alpha=0.3)
        
        # 5. Residual plot for original predictions
        axes[1, 1].scatter(y_pred_rescaled[:, i], errors_original, alpha=0.5)
        axes[1, 1].axhline(y=0, color='r', linestyle='--')
        
        # Add trend line to identify systematic bias
        z = np.polyfit(y_pred_rescaled[:, i], errors_original, 1)
        p = np.poly1d(z)
        axes[1, 1].plot(y_pred_rescaled[:, i], p(y_pred_rescaled[:, i]), "b--", alpha=0.8, 
                       label=f'Trend: {z[0]:.4f}x + {z[1]:.4f}')
        
        axes[1, 1].set_xlabel('Predicted Values')
        axes[1, 1].set_ylabel('Residuals')
        axes[1, 1].set_title('Residual Plot (Original)')
        axes[1, 1].legend()
        axes[1, 1].grid(True, alpha=0.3)
        
        # 6. Residual plot for corrected predictions
        axes[1, 2].scatter(y_pred_corrected[:, i], errors_corrected, alpha=0.5, color='green')
        axes[1, 2].axhline(y=0, color='r', linestyle='--')
        
        # Add trend line to identify systematic bias
        z_corrected = np.polyfit(y_pred_corrected[:, i], errors_corrected, 1)
        p_corrected = np.poly1d(z_corrected)
        axes[1, 2].plot(y_pred_corrected[:, i], p_corrected(y_pred_corrected[:, i]), "b--", alpha=0.8, 
                       label=f'Trend: {z_corrected[0]:.4f}x + {z_corrected[1]:.4f}')
        
        axes[1, 2].set_xlabel('Predicted Values')
        axes[1, 2].set_ylabel('Residuals')
        axes[1, 2].set_title('Residual Plot (Corrected)')
        axes[1, 2].legend()
        axes[1, 2].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(os.path.join(save_path, f'evaluation_{target_name.replace(" ", "_").replace("/", "_")}.png'), 
                   dpi=300, bbox_inches='tight')
        plt.close()
    
    # Create a combined metrics table
    metrics_data = []
    for i, target_name in enumerate(TARGET_NAMES):
        target_mse = mean_squared_error(y_val_rescaled[:, i], y_pred_rescaled[:, i])
        target_mae = mean_absolute_error(y_val_rescaled[:, i], y_pred_rescaled[:, i])
        target_r2 = r2_score(y_val_rescaled[:, i], y_pred_rescaled[:, i])
        
        target_mse_corrected = mean_squared_error(y_val_rescaled[:, i], y_pred_corrected[:, i])
        target_mae_corrected = mean_absolute_error(y_val_rescaled[:, i], y_pred_corrected[:, i])
        target_r2_corrected = r2_score(y_val_rescaled[:, i], y_pred_corrected[:, i])
        
        metrics_data.append([target_name, target_mse, target_mae, target_r2, 
                            target_mse_corrected, target_mae_corrected, target_r2_corrected])
    
    metrics_df = pd.DataFrame(metrics_data, 
                             columns=['Target', 'MSE_Original', 'MAE_Original', 'R2_Original',
                                     'MSE_Corrected', 'MAE_Corrected', 'R2_Corrected'])
    metrics_df.to_csv(os.path.join(save_path, 'metrics_summary.csv'), index=False)
    print("\nMetrics summary saved to metrics_summary.csv")
    
    # Save detailed error analysis
    error_analysis = {}
    for i, target_name in enumerate(TARGET_NAMES):
        error_analysis[f'True_{target_name}'] = y_val_rescaled[:, i]
        error_analysis[f'Pred_{target_name}'] = y_pred_rescaled[:, i]
        error_analysis[f'Corrected_{target_name}'] = y_pred_corrected[:, i]
        error_analysis[f'Error_{target_name}'] = y_pred_rescaled[:, i] - y_val_rescaled[:, i]
        error_analysis[f'CorrectedError_{target_name}'] = y_pred_corrected[:, i] - y_val_rescaled[:, i]
    
    error_analysis_df = pd.DataFrame(error_analysis)
    error_analysis_df.to_csv(os.path.join(save_path, 'error_analysis.csv'), index=False)
    print("Detailed error analysis saved to error_analysis.csv")
    
    return y_pred_corrected, mse, mse_corrected

def run_experiment(sequence_length, parent_output_dir):
    """Run a complete experiment for a specific sequence length"""
    # Set random seeds for reproducibility
    np.random.seed(RANDOM_STATE)
    tf.random.set_seed(RANDOM_STATE)
    
    # Create output directory
    output_dir = os.path.join(parent_output_dir, f"seq_{sequence_length}")
    os.makedirs(output_dir, exist_ok=True)
    
    try:
        # Load and preprocess data with scaling
        print(f"Loading and preprocessing data for sequence length {sequence_length}...")
        folder_path = os.path.expanduser("~/Desktop/CLEANED3")
        sequences, targets, file_names, feature_scaler, target_scaler = load_and_preprocess_data(folder_path, sequence_length)
        
        print(f"Created {len(sequences)} sequences of length {sequence_length}")
        print(f"Input shape: {sequences.shape}, Target shape: {targets.shape}")
        
        # Split data into training and validation sets
        X_train, X_val, y_train, y_val = create_train_val_split(sequences, targets, file_names)
        print(f"Training set: {X_train.shape}, Validation set: {X_val.shape}")
        
        # Build and compile model
        print("Building revised TCN model...")
        model = build_tcn_model((sequence_length, X_train.shape[2]), y_train.shape[1])
        model.summary()
        
        # Train model
        print("Training model...")
        history = model.fit(
            X_train, y_train,
            batch_size=BATCH_SIZE,
            epochs=EPOCHS,
            validation_data=(X_val, y_val),
            verbose=1,
            callbacks=[
                tf.keras.callbacks.EarlyStopping(patience=20, restore_best_weights=True),
                tf.keras.callbacks.ReduceLROnPlateau(factor=0.5, patience=10, min_lr=1e-6)
            ]
        )
        
        # Plot training history
        plot_training_history(history, output_dir)
        
        # Evaluate model and create detailed plots with bias correction
        print("Evaluating model and creating plots...")
        y_pred_corrected, mse, mse_corrected = evaluate_model(model, X_val, y_val, target_scaler, output_dir, sequence_length)
        
        # Save model, scalers, and metadata
        model.save(os.path.join(output_dir, 'trained_model.keras'))
        
        with open(os.path.join(output_dir, 'feature_scaler.pkl'), 'wb') as f:
            pickle.dump(feature_scaler, f)
            
        with open(os.path.join(output_dir, 'target_scaler.pkl'), 'wb') as f:
            pickle.dump(target_scaler, f)
        
        with open(os.path.join(output_dir, 'training_metadata.pkl'), 'wb') as f:
            pickle.dump({
                'X_train_shape': X_train.shape,
                'X_val_shape': X_val.shape,
                'y_train_shape': y_train.shape,
                'y_val_shape': y_val.shape,
                'target_indices': TARGET_INDICES,
                'target_names': TARGET_NAMES,
                'sequence_length': sequence_length,
                'training_history': history.history
            }, f)
        
        # Save the final evaluation metrics to a text file
        y_pred = model.predict(X_val)
        y_val_rescaled = target_scaler.inverse_transform(y_val)
        y_pred_rescaled = target_scaler.inverse_transform(y_pred)
        y_pred_corrected = apply_bias_correction(y_pred_rescaled, y_val_rescaled)
        
        with open(os.path.join(output_dir, 'evaluation_metrics.txt'), 'w') as f:
            f.write("TCN Model Evaluation Metrics\n")
            f.write("============================\n\n")
            
            # Overall metrics
            mse = mean_squared_error(y_val_rescaled, y_pred_rescaled)
            mae = mean_absolute_error(y_val_rescaled, y_pred_rescaled)
            r2 = r2_score(y_val_rescaled, y_pred_rescaled)
            
            mse_corrected = mean_squared_error(y_val_rescaled, y_pred_corrected)
            mae_corrected = mean_absolute_error(y_val_rescaled, y_pred_corrected)
            r2_corrected = r2_score(y_val_rescaled, y_pred_corrected)
            
            f.write(f"Overall Metrics (Original):\n")
            f.write(f"MSE: {mse:.6f}\n")
            f.write(f"MAE: {mae:.6f}\n")
            f.write(f"R²: {r2:.6f}\n\n")
            
            f.write(f"Overall Metrics (Corrected):\n")
            f.write(f"MSE: {mse_corrected:.6f}\n")
            f.write(f"MAE: {mae_corrected:.6f}\n")
            f.write(f"R²: {r2_corrected:.6f}\n\n")
            
            f.write(f"Improvement:\n")
            f.write(f"MSE: {((mse - mse_corrected)/mse*100):.2f}%\n")
            f.write(f"MAE: {((mae - mae_corrected)/mae*100):.2f}%\n\n")
            
            # Individual target metrics
            f.write("Per-Target Metrics:\n")
            f.write("------------------\n")
            for i, target_name in enumerate(TARGET_NAMES):
                target_mse = mean_squared_error(y_val_rescaled[:, i], y_pred_rescaled[:, i])
                target_mae = mean_absolute_error(y_val_rescaled[:, i], y_pred_rescaled[:, i])
                target_r2 = r2_score(y_val_rescaled[:, i], y_pred_rescaled[:, i])
                
                target_mse_corrected = mean_squared_error(y_val_rescaled[:, i], y_pred_corrected[:, i])
                target_mae_corrected = mean_absolute_error(y_val_rescaled[:, i], y_pred_corrected[:, i])
                target_r2_corrected = r2_score(y_val_rescaled[:, i], y_pred_corrected[:, i])
                
                f.write(f"{target_name} (Original):\n")
                f.write(f"  MSE: {target_mse:.6f}\n")
                f.write(f"  MAE: {target_mae:.6f}\n")
                f.write(f"  R²: {target_r2:.6f}\n")
                
                f.write(f"{target_name} (Corrected):\n")
                f.write(f"  MSE: {target_mse_corrected:.6f}\n")
                f.write(f"  MAE: {target_mae_corrected:.6f}\n")
                f.write(f"  R²: {target_r2_corrected:.6f}\n")
                
                f.write(f"Improvement: MSE {((target_mse - target_mse_corrected)/target_mse*100):.2f}%\n\n")
        
        print(f"Training completed for sequence length {sequence_length}. Results saved to {output_dir}")
        
        return {
            'sequence_length': sequence_length,
            'mse': mse,
            'mse_corrected': mse_corrected,
            'improvement': ((mse - mse_corrected)/mse*100)
        }
    
    except Exception as e:
        print(f"Error running experiment for sequence length {sequence_length}: {str(e)}")
        return None

def create_summary_plot(results, save_path):
    """Create a summary plot showing performance across different sequence lengths"""
    # Filter out None results
    results = [r for r in results if r is not None]
    
    if not results:
        print("No valid results to create summary plot")
        return
    
    seq_lengths = [r['sequence_length'] for r in results]
    mses = [r['mse'] for r in results]
    mses_corrected = [r['mse_corrected'] for r in results]
    improvements = [r['improvement'] for r in results]
    
    plt.figure(figsize=(15, 5))
    
    # MSE plot
    plt.subplot(1, 3, 1)
    plt.plot(seq_lengths, mses, 'o-', label='Original MSE')
    plt.plot(seq_lengths, mses_corrected, 'o-', label='Corrected MSE')
    plt.xlabel('Sequence Length')
    plt.ylabel('MSE')
    plt.title('MSE vs Sequence Length')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # Improvement plot
    plt.subplot(1, 3, 2)
    plt.plot(seq_lengths, improvements, 'o-', color='green')
    plt.xlabel('Sequence Length')
    plt.ylabel('Improvement (%)')
    plt.title('Improvement from Bias Correction')
    plt.grid(True, alpha=0.3)
    
    # Bar chart comparison
    plt.subplot(1, 3, 3)
    x = np.arange(len(seq_lengths))
    width = 0.35
    plt.bar(x - width/2, mses, width, label='Original MSE')
    plt.bar(x + width/2, mses_corrected, width, label='Corrected MSE')
    plt.xlabel('Sequence Length')
    plt.ylabel('MSE')
    plt.title('MSE Comparison by Sequence Length')
    plt.xticks(x, seq_lengths)
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(os.path.join(save_path, 'sequence_length_summary.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # Save summary table
    summary_df = pd.DataFrame(results)
    summary_df.to_csv(os.path.join(save_path, 'sequence_length_summary.csv'), index=False)

def main():
    # Create main output directory
    parent_output_dir = "TCN"
    os.makedirs(parent_output_dir, exist_ok=True)
    
    # Run experiments for all sequence lengths
    results = []
    for seq_len in SEQUENCE_LENGTHS:
        result = run_experiment(seq_len, parent_output_dir)
        results.append(result)
    
    # Create summary of all experiments
    create_summary_plot(results, parent_output_dir)
    
    print(f"\nAll experiments completed. Results saved to {parent_output_dir}")
    print("Summary of results:")
    for result in results:
        if result is not None:
            print(f"SeqLen {result['sequence_length']}: MSE={result['mse']:.6f}, "
                  f"Corrected MSE={result['mse_corrected']:.6f}, "
                  f"Improvement={result['improvement']:.2f}%")

if __name__ == "__main__":
    main()