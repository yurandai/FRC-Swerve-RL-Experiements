import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from scipy import stats
from tensorflow.keras.models import Sequential, save_model
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.optimizers import Adam
from tensorflow.keras import regularizers
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau, Callback
import datetime
import joblib

# Create results directory with timestamp
timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
results_dir = f"unified_model_results_{timestamp}"
os.makedirs(results_dir, exist_ok=True)

# Define paths and parameters
data_folder = os.path.expanduser("~/Desktop/CLEANED3")
output_columns_driving = [5, 6, 7, 8]  # Driving motor velocities
output_columns_steering = [17, 18, 19, 20]  # Steering motor velocities
target_names = [f"Motor_{col}" for col in output_columns_driving + output_columns_steering]

# Custom callback to track learning rate
class LearningRateTracker(Callback):
    def on_epoch_begin(self, epoch, logs=None):
        if not hasattr(self, 'lr_history'):
            self.lr_history = []
        lr = float(self.model.optimizer.learning_rate.numpy())
        self.lr_history.append(lr)

# Load all files without shuffling
file_paths = [os.path.join(data_folder, f) for f in os.listdir(data_folder) if f.endswith('.csv')]
train_files = file_paths[:int(0.8 * len(file_paths))]  # First 80% of files for training
test_files = file_paths[int(0.8 * len(file_paths)):]   # Last 20% for testing

# Function to load data from files (single timestep for all motors)
def load_data(files):
    X_data = []
    y_data_all = []
    
    for file in files:
        df = pd.read_csv(file)
        numeric_df = df.iloc[1:].apply(pd.to_numeric, errors='coerce').dropna()
        time_values = numeric_df.iloc[:, 0].values
        data_values = numeric_df.iloc[:, 1:].values  # All columns except timestamp
        
        # Single timestep data for all motors
        for i in range(1, len(numeric_df)):
            # Calculate time difference between consecutive timesteps
            time_diff = time_values[i] - time_values[i-1]
            
            # Use all features from previous time step (excluding timestamp) + time difference
            features = np.append(data_values[i-1], time_diff)
            X_data.append(features)
            
            # Target includes both driving and steering motor velocities
            driving_targets = data_values[i, [col-1 for col in output_columns_driving]]
            steering_targets = data_values[i, [col-1 for col in output_columns_steering]]
            all_targets = np.concatenate((driving_targets, steering_targets))
            y_data_all.append(all_targets)
    
    return np.array(X_data), np.array(y_data_all)

print("Loading training data...")
X_train, y_train_all = load_data(train_files)
X_test, y_test_all = load_data(test_files)

print(f"Data shapes: X={X_train.shape}, y={y_train_all.shape}")

# Scale data
x_scaler = StandardScaler()
X_train_scaled = x_scaler.fit_transform(X_train)
X_test_scaled = x_scaler.transform(X_test)

y_scaler = StandardScaler()
y_train_scaled = y_scaler.fit_transform(y_train_all)
y_test_scaled = y_scaler.transform(y_test_all)

# Build unified model for all motors
model = Sequential([
    Dense(256, activation='relu', input_shape=(X_train_scaled.shape[1],),
          kernel_regularizer=regularizers.l2(0.001)),
    Dropout(0.3),
    Dense(128, activation='relu', kernel_regularizer=regularizers.l2(0.001)),
    Dropout(0.3),
    Dense(64, activation='relu'),
    Dropout(0.2),
    Dense(32, activation='relu'),
    Dense(len(output_columns_driving) + len(output_columns_steering))  # 8 outputs
])
model.compile(optimizer=Adam(0.001), loss='mse', metrics=['mae'])

# Callbacks for early stopping and learning rate reduction
early_stopping = EarlyStopping(monitor='val_loss', patience=15, restore_best_weights=True)
reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=5, min_lr=1e-6)
lr_tracker = LearningRateTracker()

# Train model
print("Training unified model...")
history = model.fit(X_train_scaled, y_train_scaled, 
                   epochs=100, batch_size=32, validation_split=0.2, 
                   verbose=1, callbacks=[early_stopping, reduce_lr, lr_tracker])

# Make predictions
y_pred_scaled = model.predict(X_test_scaled)
y_pred = y_scaler.inverse_transform(y_pred_scaled)

# Separate predictions for driving and steering motors
y_pred_drive = y_pred[:, :len(output_columns_driving)]
y_pred_steer = y_pred[:, len(output_columns_driving):]

y_test_drive = y_test_all[:, :len(output_columns_driving)]
y_test_steer = y_test_all[:, len(output_columns_driving):]

# Apply bias correction to all motors
def apply_bias_correction(y_pred, y_true):
    """Apply linear bias correction to predictions based on error patterns"""
    corrected_preds = np.copy(y_pred)
    for i in range(y_pred.shape[1]):
        # Calculate the error pattern
        errors = y_pred[:, i] - y_true[:, i]
        
        # Fit a linear model to predict error from prediction
        slope, intercept, r_value, p_value, std_err = stats.linregress(y_pred[:, i], errors)
        
        # Apply correction: subtract the predicted error
        corrected_preds[:, i] = y_pred[:, i] - (slope * y_pred[:, i] + intercept)
        
        print(f"Motor {i+1}: Error = {slope:.4f} * prediction + {intercept:.4f} (R²={r_value**2:.4f})")
    
    return corrected_preds

# Apply bias correction to all motors
y_pred_corrected = apply_bias_correction(y_pred, y_test_all)
y_pred_corrected_drive = y_pred_corrected[:, :len(output_columns_driving)]
y_pred_corrected_steer = y_pred_corrected[:, len(output_columns_driving):]

# Calculate metrics for each motor (original and corrected)
metrics_original = {}
metrics_corrected = {}

for i, target_name in enumerate(target_names):
    # Original predictions
    mse_orig = mean_squared_error(y_test_all[:, i], y_pred[:, i])
    mae_orig = mean_absolute_error(y_test_all[:, i], y_pred[:, i])
    r2_orig = r2_score(y_test_all[:, i], y_pred[:, i])
    
    metrics_original[target_name] = {
        'MSE': float(mse_orig),
        'MAE': float(mae_orig),
        'R2': float(r2_orig)
    }
    
    # Corrected predictions
    mse_corr = mean_squared_error(y_test_all[:, i], y_pred_corrected[:, i])
    mae_corr = mean_absolute_error(y_test_all[:, i], y_pred_corrected[:, i])
    r2_corr = r2_score(y_test_all[:, i], y_pred_corrected[:, i])
    
    metrics_corrected[target_name] = {
        'MSE': float(mse_corr),
        'MAE': float(mae_corr),
        'R2': float(r2_corr)
    }

# Calculate overall metrics
overall_mse_orig = mean_squared_error(y_test_all.flatten(), y_pred.flatten())
overall_mae_orig = mean_absolute_error(y_test_all.flatten(), y_pred.flatten())
overall_r2_orig = r2_score(y_test_all.flatten(), y_pred.flatten())

overall_mse_corr = mean_squared_error(y_test_all.flatten(), y_pred_corrected.flatten())
overall_mae_corr = mean_absolute_error(y_test_all.flatten(), y_pred_corrected.flatten())
overall_r2_corr = r2_score(y_test_all.flatten(), y_pred_corrected.flatten())

metrics_original['Overall'] = {
    'MSE': float(overall_mse_orig),
    'MAE': float(overall_mae_orig),
    'R2': float(overall_r2_orig)
}

metrics_corrected['Overall'] = {
    'MSE': float(overall_mse_corr),
    'MAE': float(overall_mae_corr),
    'R2': float(overall_r2_corr)
}

# Save metrics to text file
with open(os.path.join(results_dir, 'metrics_summary.txt'), 'w') as f:
    f.write("Motor Performance Metrics (Unified Model)\n")
    f.write("=" * 60 + "\n\n")
    
    f.write("ORIGINAL PREDICTIONS:\n")
    f.write("=" * 25 + "\n")
    for motor, values in metrics_original.items():
        if motor == 'Overall':
            f.write("\nOverall System Performance:\n")
            f.write("-" * 30 + "\n")
        else:
            f.write(f"{motor}:\n")
            f.write("-" * len(motor) + "\n")
        
        f.write(f"MSE: {values['MSE']:.6f}\n")
        f.write(f"MAE: {values['MAE']:.6f}\n")
        f.write(f"R²: {values['R2']:.6f}\n\n")
    
    f.write("\n\nBIAS-CORRECTED PREDICTIONS:\n")
    f.write("=" * 30 + "\n")
    for motor, values in metrics_corrected.items():
        if motor == 'Overall':
            f.write("\nOverall System Performance:\n")
            f.write("-" * 30 + "\n")
        else:
            f.write(f"{motor}:\n")
            f.write("-" * len(motor) + "\n")
        
        f.write(f"MSE: {values['MSE']:.6f}\n")
        f.write(f"MAE: {values['MAE']:.6f}\n")
        f.write(f"R²: {values['R2']:.6f}\n\n")
    
    # Calculate improvement percentages
    f.write("\n\nIMPROVEMENT AFTER BIAS CORRECTION:\n")
    f.write("=" * 40 + "\n")
    for motor in target_names:
        mse_imp = (metrics_original[motor]['MSE'] - metrics_corrected[motor]['MSE']) / metrics_original[motor]['MSE'] * 100
        mae_imp = (metrics_original[motor]['MAE'] - metrics_corrected[motor]['MAE']) / metrics_original[motor]['MAE'] * 100
        r2_imp = (metrics_corrected[motor]['R2'] - metrics_original[motor]['R2']) / abs(metrics_original[motor]['R2']) * 100
        
        f.write(f"{motor}:\n")
        f.write(f"  MSE Improvement: {mse_imp:.2f}%\n")
        f.write(f"  MAE Improvement: {mae_imp:.2f}%\n")
        f.write(f"  R² Improvement: {r2_imp:.2f}%\n\n")
    
    # Overall improvement
    mse_imp_overall = (overall_mse_orig - overall_mse_corr) / overall_mse_orig * 100
    mae_imp_overall = (overall_mae_orig - overall_mae_corr) / overall_mae_orig * 100
    r2_imp_overall = (overall_r2_corr - overall_r2_orig) / abs(overall_r2_orig) * 100
    
    f.write("Overall System:\n")
    f.write(f"  MSE Improvement: {mse_imp_overall:.2f}%\n")
    f.write(f"  MAE Improvement: {mae_imp_overall:.2f}%\n")
    f.write(f"  R² Improvement: {r2_imp_overall:.2f}%\n")

# Plot training history
plt.figure(figsize=(10, 5))
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('Unified Model - MSE Loss')
plt.xlabel('Epoch')
plt.ylabel('MSE')
plt.legend()
plt.grid(True, alpha=0.3)
plt.savefig(os.path.join(results_dir, 'training_history.png'), dpi=300, bbox_inches='tight')
plt.close()

# Create evaluation plots for each motor (6 subplots each)
for i, target_name in enumerate(target_names):
    print(f"Creating plots for {target_name}...")
    
    # Create figure with 6 subplots
    fig, axes = plt.subplots(2, 3, figsize=(20, 12))
    fig.suptitle(f'Evaluation for {target_name}', fontsize=16)
    
    # Calculate metrics for this motor
    target_mse_orig = mean_squared_error(y_test_all[:, i], y_pred[:, i])
    target_mae_orig = mean_absolute_error(y_test_all[:, i], y_pred[:, i])
    target_r2_orig = r2_score(y_test_all[:, i], y_pred[:, i])
    
    target_mse_corr = mean_squared_error(y_test_all[:, i], y_pred_corrected[:, i])
    target_mae_corr = mean_absolute_error(y_test_all[:, i], y_pred_corrected[:, i])
    target_r2_corr = r2_score(y_test_all[:, i], y_pred_corrected[:, i])
    
    # 1. Scatter plot of true vs predicted values (original)
    axes[0, 0].scatter(y_test_all[:, i], y_pred[:, i], alpha=0.5, label='Original')
    min_val = min(y_test_all[:, i].min(), y_pred[:, i].min())
    max_val = max(y_test_all[:, i].max(), y_pred[:, i].max())
    axes[0, 0].plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=2)
    axes[0, 0].set_xlabel('True Values')
    axes[0, 0].set_ylabel('Predictions')
    axes[0, 0].set_title(f'Original: MSE={target_mse_orig:.6f}')
    axes[0, 0].grid(True, alpha=0.3)
    
    # 2. Scatter plot of true vs predicted values (corrected)
    axes[0, 1].scatter(y_test_all[:, i], y_pred_corrected[:, i], alpha=0.5, label='Corrected', color='green')
    axes[0, 1].plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=2)
    axes[0, 1].set_xlabel('True Values')
    axes[0, 1].set_ylabel('Predictions')
    axes[0, 1].set_title(f'Corrected: MSE={target_mse_corr:.6f}')
    axes[0, 1].grid(True, alpha=0.3)
    
    # 3. Error distribution comparison
    errors_original = y_pred[:, i] - y_test_all[:, i]
    errors_corrected = y_pred_corrected[:, i] - y_test_all[:, i]
    
    axes[0, 2].hist(errors_original, bins=50, alpha=0.7, label='Original', edgecolor='black')
    axes[0, 2].hist(errors_corrected, bins=50, alpha=0.7, label='Corrected', edgecolor='black')
    axes[0, 2].axvline(x=0, color='r', linestyle='--')
    axes[0, 2].set_xlabel('Prediction Error')
    axes[0, 2].set_ylabel('Frequency')
    axes[0, 2].set_title('Error Distribution Comparison')
    axes[0, 2].legend()
    axes[0, 2].grid(True, alpha=0.3)
    
    # 4. Time series comparison (first 100 samples)
    n_samples = min(100, len(y_test_all))
    axes[1, 0].plot(range(n_samples), y_test_all[:n_samples, i], label='True', linewidth=2)
    axes[1, 0].plot(range(n_samples), y_pred[:n_samples, i], label='Original Pred', linewidth=2, alpha=0.8)
    axes[1, 0].plot(range(n_samples), y_pred_corrected[:n_samples, i], label='Corrected Pred', linewidth=2, alpha=0.8)
    axes[1, 0].set_xlabel('Time Step')
    axes[1, 0].set_ylabel('Value')
    axes[1, 0].set_title('Time Series Comparison')
    axes[1, 0].legend()
    axes[1, 0].grid(True, alpha=0.3)
    
    # 5. Residual plot for original predictions
    axes[1, 1].scatter(y_pred[:, i], errors_original, alpha=0.5)
    axes[1, 1].axhline(y=0, color='r', linestyle='--')
    
    # Add trend line to identify systematic bias
    z = np.polyfit(y_pred[:, i], errors_original, 1)
    p = np.poly1d(z)
    axes[1, 1].plot(y_pred[:, i], p(y_pred[:, i]), "b--", alpha=0.8, 
                   label=f'Trend: {z[0]:.4f}x + {z[1]:.4f}')
    
    axes[1, 1].set_xlabel('Predicted Values')
    axes[1, 1].set_ylabel('Residuals')
    axes[1, 1].set_title('Residual Plot (Original)')
    axes[1, 1].legend()
    axes[1, 1].grid(True, alpha=0.3)
    
    # 6. Residual plot for corrected predictions
    axes[1, 2].scatter(y_pred_corrected[:, i], errors_corrected, alpha=0.5, color='green')
    axes[1, 2].axhline(y=0, color='r', linestyle='--')
    
    # Add trend line to identify systematic bias
    z_corrected = np.polyfit(y_pred_corrected[:, i], errors_corrected, 1)
    p_corrected = np.poly1d(z_corrected)
    axes[1, 2].plot(y_pred_corrected[:, i], p_corrected(y_pred_corrected[:, i]), "b--", alpha=0.8, 
                   label=f'Trend: {z_corrected[0]:.4f}x + {z_corrected[1]:.4f}')
    
    axes[1, 2].set_xlabel('Predicted Values')
    axes[1, 2].set_ylabel('Residuals')
    axes[1, 2].set_title('Residual Plot (Corrected)')
    axes[1, 2].legend()
    axes[1, 2].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(os.path.join(results_dir, f'evaluation_{target_name}.png'), dpi=300, bbox_inches='tight')
    plt.close()

# Save model
model.save(os.path.join(results_dir, 'unified_model.keras'))

# Save scalers
joblib.dump(x_scaler, os.path.join(results_dir, 'x_scaler.pkl'))
joblib.dump(y_scaler, os.path.join(results_dir, 'y_scaler.pkl'))

print(f"\nAll results saved to: {results_dir}")
print("Process completed successfully!")