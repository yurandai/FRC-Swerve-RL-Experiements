import os
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import gymnasium as gym
from gymnasium import spaces
from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.monitor import Monitor
import pygame

class PygameVisualizer:
    def __init__(self):
        pygame.init()
        self.screen_width = 800
        self.screen_height = 600
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        pygame.display.set_caption("Robot Visualization")
        self.clock = pygame.time.Clock()
        self.scale = 100  # pixels per meter
        self.robot_width = 0.618  # trackwidth
        self.robot_length = 0.618  # wheelbase
        self.wheel_radius = 0.0508
        self.field_y_min = -2
        self.field_y_max = 7

    def draw_robot(self, y, linear_vel, voltages):
        self.screen.fill((255, 255, 255))  # White background
        
        for fy in range(int(self.field_y_min), int(self.field_y_max) + 1):
            py = self.screen_height // 2 - int(fy * self.scale)
            pygame.draw.line(self.screen, (200, 200, 200), (0, py), (self.screen_width, py))
        
        robot_center_x = self.screen_width // 2
        robot_center_y = self.screen_height // 2 - int(y * self.scale)
        
        robot_rect = pygame.Rect(
            robot_center_x - int(self.robot_width * self.scale / 2),
            robot_center_y - int(self.robot_length * self.scale / 2),
            int(self.robot_width * self.scale),
            int(self.robot_length * self.scale)
        )
        pygame.draw.rect(self.screen, (0, 0, 255), robot_rect)
        
        wheel_positions = [
            (robot_rect.left + int(self.wheel_radius * self.scale), robot_rect.top + int(self.wheel_radius * self.scale)),
            (robot_rect.right - int(self.wheel_radius * self.scale), robot_rect.top + int(self.wheel_radius * self.scale)),
            (robot_rect.left + int(self.wheel_radius * self.scale), robot_rect.bottom - int(self.wheel_radius * self.scale)),
            (robot_rect.right - int(self.wheel_radius * self.scale), robot_rect.bottom - int(self.wheel_radius * self.scale)),
        ]
        for i, pos in enumerate(wheel_positions):
            pygame.draw.circle(self.screen, (0, 0, 0), pos, int(self.wheel_radius * self.scale))
        
        target_y = self.screen_height // 2 - int(3 * self.scale)
        pygame.draw.line(self.screen, (255, 0, 0), (0, target_y), (self.screen_width, target_y))
        
        font = pygame.font.Font(None, 24)
        text_vel = font.render(f"Linear Vel: {linear_vel:.2f} m/s", True, (0, 0, 0))
        text_y = font.render(f"Y: {y:.2f} m", True, (0, 0, 0))
        text_volts = font.render(f"Voltages: {voltages[0]:.1f}, {voltages[1]:.1f}, {voltages[2]:.1f}, {voltages[3]:.1f}", True, (0, 0, 0))
        self.screen.blit(text_vel, (10, 10))
        self.screen.blit(text_y, (10, 40))
        self.screen.blit(text_volts, (10, 70))
        
        pygame.display.flip()

    def replay_episode(self, df, dt):
        running = True
        for _, row in df.iterrows():
            if not running:
                break
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
            if row['time'] == 0:
                continue
            y = row['position_y']
            linear_vel = row['linear_vel']
            voltages = [row[f'voltage{i}'] for i in range(4)]
            self.draw_robot(y, linear_vel, voltages)
            self.clock.tick(1 / dt)
        time.sleep(2)

    def close(self):
        pygame.quit()

class RobotEnv(gym.Env):
    def __init__(self, visualizer=None):
        super().__init__()
        self.wheel_radius = 0.0508  # meters
        self.gear_ratio = 6.12
        self.dt = 0.02
        self.max_steps = 1000
        self.current_step = 0
        self.visualizer = visualizer
        self.prev_linear_vel = 0.0  # For smoothing

        self.ks = [0.1792, 0.1280, 0.0832, 0.0954]
        self.kv_original = [0.8673, 0.9056, 0.9103, 0.8927]
        scale_factor = 0.0327 / (sum(self.kv_original)/4)
        self.kv = [kv * scale_factor for kv in self.kv_original]
        self.ka = [max(0.0018, 0.001), max(0.0001, 0.001), max(-0.0005, 0.001), max(0.0002, 0.001)]
        self.intercepts = [-0.0015, 0.0027, 0.0100, 0.0003]

        self.target_y = 3.0
        self.position_range = 0.05  # Fixed ±5cm for termination
        self.velocity_tolerance = 0.5

        self.boundary_y_min = -2.0
        self.boundary_y_max = 7.0

        self.max_linear_vel = 3.0
        self.max_linear_acc = 4.0
        self.motor_max = (self.max_linear_vel / self.wheel_radius) * self.gear_ratio * 1.5

        self.action_space = spaces.Box(low=-self.max_linear_vel, high=self.max_linear_vel, shape=(1,), dtype=np.float32)
        self.observation_space = spaces.Box(
            low=np.array([-10, -500, -500, -500, -500]),
            high=np.array([10, 500, 500, 500, 500]),
            dtype=np.float32
        )

        self.state = None

    def reset(self, *, seed=None, options=None):
        self.state = np.array([0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float32)
        self.current_step = 0
        self.prev_linear_vel = 0.0
        return self.state.copy(), {}

    def step(self, action):
        desired_linear_vel = action[0]
        y, v0, v1, v2, v3 = self.state
        motor_vels = [v0, v1, v2, v3]

        old_dist = abs(y - self.target_y)

        desired_wheel_rad_sec = desired_linear_vel / self.wheel_radius
        desired_motor_rad_sec = desired_wheel_rad_sec * self.gear_ratio

        voltages = []
        actual_accs = []
        reward = 0.0

        for i in range(4):
            desired_acc = (desired_motor_rad_sec - motor_vels[i]) / self.dt
            motor_acc_max = (self.max_linear_acc / self.wheel_radius) * self.gear_ratio
            motor_acc = np.clip(desired_acc, -motor_acc_max, motor_acc_max)
            voltage = self.ks[i] * np.sign(desired_motor_rad_sec) + self.kv[i] * desired_motor_rad_sec + self.ka[i] * motor_acc + self.intercepts[i]
            excess = max(0, abs(voltage) - 12)
            reward -= 0.05 * excess
            voltage = np.clip(voltage, -12, 12)
            voltages.append(voltage)
            actual_acc = (voltage - self.ks[i] * np.sign(motor_vels[i]) - self.kv[i] * motor_vels[i] - self.intercepts[i]) / self.ka[i]
            actual_acc = np.clip(actual_acc, -motor_acc_max, motor_acc_max)
            actual_accs.append(actual_acc)

        new_motor_vels = [motor_vels[i] + actual_accs[i] * self.dt for i in range(4)]
        new_motor_vels = [max(-self.motor_max, min(self.motor_max, vel)) for vel in new_motor_vels]

        wheel_rad_secs = [new_motor_vels[i] / self.gear_ratio for i in range(4)]

        linear_vel = np.mean(wheel_rad_secs) * self.wheel_radius

        new_y = y + linear_vel * self.dt

        new_dist = abs(new_y - self.target_y)

        # Reward
        if new_dist < old_dist:
            reward += 10.0 * (old_dist - new_dist)
        if y < 2.8:
            reward -= 0.5
            if new_dist > 0.5:
                reward += 0.3 * min(linear_vel, 2.5)
        if y >= 2.0:
            reward -= 0.1 * (1 - np.exp(-5 * (3 - y))) * linear_vel ** 2
        reward -= 0.00005 * sum(v ** 2 for v in voltages) * self.dt
        reward -= 1.0 * np.var(wheel_rad_secs)
        reward -= 0.02 * abs(linear_vel - self.prev_linear_vel)  # Tuned lower for less damping
        self.prev_linear_vel = linear_vel

        terminated = False
        truncated = False

        if new_y < self.boundary_y_min or new_y > self.boundary_y_max:
            reward -= 100
            terminated = True

        if new_dist <= self.position_range:
            vel_error = abs(linear_vel)
            if vel_error < 0.01:
                reward += 1000
            else:
                reward -= 50 * vel_error
            terminated = True

        self.current_step += 1
        if self.current_step >= self.max_steps:
            truncated = True

        self.state = np.array([new_y] + new_motor_vels)

        info = {'voltages': voltages, 'linear_vel': linear_vel}

        return self.state.copy(), reward, terminated, truncated, info

class LogWrapper(gym.Wrapper):
    def __init__(self, env, log_dir, visualizer):
        super().__init__(env)
        self.log_dir = log_dir
        self.visualizer = visualizer
        self.episode_count = 0
        self.current_episode = []
        self.total_reward = 0.0
        self.successes = 0
        self.episode_rewards = []
        self.max_reward = -np.inf
        self.best_episode_num = 0

    def reset(self, **kwargs):
        if self.current_episode:
            self.save_episode()
        self.current_episode = []
        self.total_reward = 0.0
        self.episode_count += 1
        obs, info = self.env.reset(**kwargs)
        time_step = 0.0
        position_y = obs[0]
        linear_vel = 0.0
        self.current_episode.append({
            'time': time_step,
            'position_y': position_y,
            'linear_vel': linear_vel,
            'voltage0': None,
            'voltage1': None,
            'voltage2': None,
            'voltage3': None,
            'reward': 0.0
        })
        return obs, info

    def step(self, action):
        obs, reward, terminated, truncated, info = self.env.step(action)
        self.total_reward += reward
        time_step = len(self.current_episode) * self.env.dt
        position_y = obs[0]
        linear_vel = info['linear_vel']
        voltages = info['voltages']
        self.current_episode.append({
            'time': time_step,
            'position_y': position_y,
            'linear_vel': linear_vel,
            'voltage0': voltages[0],
            'voltage1': voltages[1],
            'voltage2': voltages[2],
            'voltage3': voltages[3],
            'reward': reward
        })
        return obs, reward, terminated, truncated, info

    def save_episode(self):
        episode_length = len(self.current_episode)
        final_dist = abs(self.current_episode[-1]['position_y'] - self.env.target_y)
        final_vel = abs(self.current_episode[-1]['linear_vel'])
        is_success = (final_dist <= self.env.position_range and final_vel < self.env.velocity_tolerance)
        if is_success:
            self.successes += 1
        print(f"Episode {self.episode_count}: Length {episode_length}, Total Reward {self.total_reward:.2f}, Success: {is_success}")

        self.episode_rewards.append(self.total_reward)
        if self.total_reward > self.max_reward:
            self.max_reward = self.total_reward
            self.best_episode_num = self.episode_count
            df = pd.DataFrame(self.current_episode)
            csv_path = os.path.join(self.log_dir, f"best_episode_{self.best_episode_num}.csv")
            df.to_csv(csv_path, index=False)
            times = df['time']
            ys = df['position_y']
            vels = df['linear_vel']
            volts0 = df['voltage0'].dropna()
            volts1 = df['voltage1'].dropna()
            volts2 = df['voltage2'].dropna()
            volts3 = df['voltage3'].dropna()
            times_for_volts = times[1:]

            fig, ax = plt.subplots()
            ax.plot(times, ys)
            ax.set_xlabel('Time (s)')
            ax.set_ylabel('Y Position (m)')
            ax.set_title(f'Best Episode {self.best_episode_num}: Y Position over Time')
            plt.savefig(os.path.join(self.log_dir, f"best_position_{self.best_episode_num}.png"))
            plt.close()

            fig, ax = plt.subplots()
            ax.plot(times, vels)
            ax.set_xlabel('Time (s)')
            ax.set_ylabel('Linear Velocity (m/s)')
            ax.set_title(f'Best Episode {self.best_episode_num}: Linear Velocity over Time')
            plt.savefig(os.path.join(self.log_dir, f"best_linear_vel_{self.best_episode_num}.png"))
            plt.close()

            fig, ax = plt.subplots()
            ax.plot(times_for_volts, volts0, label='Motor 0')
            ax.plot(times_for_volts, volts1, label='Motor 1')
            ax.plot(times_for_volts, volts2, label='Motor 2')
            ax.plot(times_for_volts, volts3, label='Motor 3')
            ax.set_xlabel('Time (s)')
            ax.set_ylabel('Voltage (V)')
            ax.set_title(f'Best Episode {self.best_episode_num}: Voltages over Time')
            ax.legend()
            plt.savefig(os.path.join(self.log_dir, f"best_voltages_{self.best_episode_num}.png"))
            plt.close()

        if self.episode_count % 100 == 0:
            print(f"Cumulative best-performing episode (max reward {self.max_reward:.2f}): #{self.best_episode_num}")

        if self.episode_count % 10 == 0:
            df = pd.DataFrame(self.current_episode)
            csv_path = os.path.join(self.log_dir, f"episode_{self.episode_count}.csv")
            df.to_csv(csv_path, index=False)

            times = df['time']
            ys = df['position_y']
            vels = df['linear_vel']
            volts0 = df['voltage0'].dropna()
            volts1 = df['voltage1'].dropna()
            volts2 = df['voltage2'].dropna()
            volts3 = df['voltage3'].dropna()
            times_for_volts = times[1:]

            fig, ax = plt.subplots()
            ax.plot(times, ys)
            ax.set_xlabel('Time (s)')
            ax.set_ylabel('Y Position (m)')
            ax.set_title(f'Episode {self.episode_count}: Y Position over Time')
            plt.savefig(os.path.join(self.log_dir, f"position_{self.episode_count}.png"))
            plt.close()

            fig, ax = plt.subplots()
            ax.plot(times, vels)
            ax.set_xlabel('Time (s)')
            ax.set_ylabel('Linear Velocity (m/s)')
            ax.set_title(f'Episode {self.episode_count}: Linear Velocity over Time')
            plt.savefig(os.path.join(self.log_dir, f"linear_vel_{self.episode_count}.png"))
            plt.close()

            fig, ax = plt.subplots()
            ax.plot(times_for_volts, volts0, label='Motor 0')
            ax.plot(times_for_volts, volts1, label='Motor 1')
            ax.plot(times_for_volts, volts2, label='Motor 2')
            ax.plot(times_for_volts, volts3, label='Motor 3')
            ax.set_xlabel('Time (s)')
            ax.set_ylabel('Voltage (V)')
            ax.set_title(f'Episode {self.episode_count}: Voltages over Time')
            ax.legend()
            plt.savefig(os.path.join(self.log_dir, f"voltages_{self.episode_count}.png"))
            plt.close()

            metrics_path = os.path.join(self.log_dir, f"metrics_{self.episode_count}.txt")
            with open(metrics_path, 'w') as f:
                f.write(f"Episode {self.episode_count}\n")
                f.write(f"Length: {episode_length}\n")
                f.write(f"Total Reward: {self.total_reward:.2f}\n")
                f.write(f"Final Position Y: {df['position_y'].iloc[-1]:.2f}\n")
                f.write(f"Final Linear Vel: {df['linear_vel'].iloc[-1]:.2f}\n")

            self.visualizer.replay_episode(df, self.env.dt)

class CurriculumCallback(BaseCallback):
    def __init__(self, log_wrapper, verbose=0):
        super().__init__(verbose)
        self.recent_rewards = []
        self.recent_successes = []
        self.recent_lengths = []
        self.reward_threshold = -1000.0
        self.success_rate_threshold = 0.8
        self.max_length_threshold = 300
        self.window_size = 100
        self.log_wrapper = log_wrapper
        self.best_model_path = self.log_wrapper.log_dir  # Save best policies

    def _on_step(self) -> bool:
        if self.locals['dones'][0]:
            episode_reward = self.locals['infos'][0]['episode']['r']
            self.recent_rewards.append(episode_reward)
            final_dist = abs(self.training_env.envs[0].state[0] - self.training_env.envs[0].target_y)
            final_vel = abs(self.locals['infos'][0]['linear_vel'])
            is_success = (final_dist <= self.training_env.envs[0].position_range and final_vel < self.training_env.envs[0].velocity_tolerance)
            self.recent_successes.append(1 if is_success else 0)
            episode_length = len(self.log_wrapper.current_episode)
            self.recent_lengths.append(episode_length)
            if len(self.recent_rewards) > self.window_size:
                self.recent_rewards.pop(0)
                self.recent_successes.pop(0)
                self.recent_lengths.pop(0)
            avg_reward = np.mean(self.recent_rewards) if self.recent_rewards else 0
            success_rate = np.mean(self.recent_successes) if self.recent_successes else 0
            avg_length = np.mean(self.recent_lengths) if self.recent_lengths else 0
            print(f"Average reward over last {len(self.recent_rewards)} episodes: {avg_reward:.2f}, Success rate: {success_rate:.2f}, Avg length: {avg_length:.2f}s")
            if avg_reward > self.reward_threshold and success_rate > self.success_rate_threshold and avg_length <= self.max_length_threshold:
                env = self.training_env.envs[0]
                env.velocity_tolerance = max(env.velocity_tolerance * 0.5, 0.005)
                env.boundary_y_min = min(env.boundary_y_min + 0.5, -0.1)
                env.boundary_y_max = max(env.boundary_y_max - 0.5, 3.1)
                print(f"Tightening velocity tolerance: vel={env.velocity_tolerance:.2f}")
                print(f"Tightening boundaries: y_min={env.boundary_y_min:.2f}, y_max={env.boundary_y_max:.2f}")
                self.reward_threshold += 200
            elif avg_length > self.max_length_threshold:
                print(f"Warning: Average episode length {avg_length:.2f}s exceeds threshold {self.max_length_threshold}s. Consider adjusting rewards.")
            # Save policy if avg_reward is new high
            if avg_reward > self.log_wrapper.max_reward:
                self.model.save(os.path.join(self.best_model_path, f"best_policy_{self.log_wrapper.episode_count}.zip"))
        return True

def main():
    desktop_path = os.path.expanduser("~/Desktop/Test")
    log_dir = os.path.join(desktop_path, "logs", time.strftime("%Y%m%d-%H%M%S"))
    os.makedirs(log_dir, exist_ok=True)

    visualizer = PygameVisualizer()
    env = RobotEnv(visualizer=visualizer)
    log_wrapper = LogWrapper(env, log_dir, visualizer)
    monitored_env = Monitor(log_wrapper)
    vec_env = DummyVecEnv([lambda: monitored_env])

    model = PPO("MlpPolicy", vec_env, verbose=1, learning_rate=0.0003, n_steps=2048)
    callback = CurriculumCallback(log_wrapper)

    model.learn(total_timesteps=2000000, callback=callback)
    model.save(os.path.join(log_dir, "ppo_model.zip"))

    visualizer.close()

if __name__ == "__main__":
    main()